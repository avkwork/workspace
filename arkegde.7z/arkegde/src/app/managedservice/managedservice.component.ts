import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managedservice',
  templateUrl: './managedservice.component.html',
  styleUrls: ['./managedservice.component.scss']
})
export class ManagedserviceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
